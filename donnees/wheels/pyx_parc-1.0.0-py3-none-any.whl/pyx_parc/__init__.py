def normaliser_nom(nom):
    return nom.strip().lower()
